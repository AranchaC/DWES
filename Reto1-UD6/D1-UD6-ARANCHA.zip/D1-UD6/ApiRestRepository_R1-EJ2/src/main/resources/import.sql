INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('HarryPotter', 'estudiante', 'Gryffindor', 'Mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('RonWeasley', 'estudiante', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('HermioneGranger', 'estudiante', 'Gryffindor', 'Muggle');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('DracoMalfoy', 'estudiante', 'Slytherin', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('MinervaMcGonagall', 'profesora', 'Gryffindor', 'Mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('LunaLovegood', 'estudiante', 'Ravenclaw', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('SeverusSnape', 'profesor', 'Slytherin', 'Muggle');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('GinnyWeasley', 'estudiante', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('NevilleLongbottom', 'estudiante', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('FredWeasley', 'estudiante', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('GeorgeWeasley', 'estudiante', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('ChoChang', 'estudiante', 'Ravenclaw', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('CedricDiggory', 'estudiante', 'Hufflepuff', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('SiriusBlack', 'prisionero', 'Gryffindor', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('RemusLupin', 'profesor', 'Gryffindor', 'Mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('BellatrixLestrange', 'mortífaga', 'Slytherin', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('Dobby', 'elfo doméstico', 'N/A', 'Sangre pura liberado');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('KingsleyShacklebolt', 'auror', 'N/A', 'Mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('NymphadoraTonks', 'auror', 'Hufflepuff', 'Sangre mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('MadEyeMoody', 'auror', 'N/A', 'Muggle');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('AlbusDumbledore', 'profesor', 'Gryffindor', 'Mestiza');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('SybillTrelawney', 'profesora', 'Ravenclaw', 'Sangre pura');
INSERT INTO Personaje (nombre, rol, casa, ascendencia) VALUES ('FiliusFlitwick', 'profesor', 'Ravenclaw', 'Sangre mestiza');


