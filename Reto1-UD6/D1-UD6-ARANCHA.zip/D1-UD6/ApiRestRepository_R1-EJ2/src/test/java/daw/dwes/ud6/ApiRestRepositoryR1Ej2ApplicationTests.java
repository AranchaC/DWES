package daw.dwes.ud6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestRepositoryR1Ej2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
