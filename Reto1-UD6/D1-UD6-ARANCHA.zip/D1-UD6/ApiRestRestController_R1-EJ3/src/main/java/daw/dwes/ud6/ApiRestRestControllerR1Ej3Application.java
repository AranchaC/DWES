package daw.dwes.ud6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRestRestControllerR1Ej3Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiRestRestControllerR1Ej3Application.class, args);
	}

}
