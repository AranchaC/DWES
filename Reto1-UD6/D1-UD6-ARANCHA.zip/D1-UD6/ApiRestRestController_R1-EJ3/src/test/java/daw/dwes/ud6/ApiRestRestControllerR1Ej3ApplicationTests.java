package daw.dwes.ud6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestRestControllerR1Ej3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
