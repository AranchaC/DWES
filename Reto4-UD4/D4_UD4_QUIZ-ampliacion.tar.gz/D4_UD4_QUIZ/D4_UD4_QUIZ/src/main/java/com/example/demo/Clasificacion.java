package com.example.demo;

public enum Clasificacion {
	GRYFFINDOR, RAVENCLAW, SLYTHERIN, HUFFLEPUFF
}
