<?php

?>

<html>
    <head>
    <title>Ejercicio 2 FIN</title>
    </head>
    <body>
        <h1>Ejercicio 2 resumen:</h1>
        <p>Nombre: <?php echo $_REQUEST["nombre"] ?></p>
        <p>Ciudad: <?php echo $_REQUEST["ciudad"] ?></p>
        <p>Edad: <?php echo $_REQUEST["edad"] ?></p>
        <p><a href="Ejercicio2-1.php">Volver a empezar</a></p>

        <form action="">
            <input type="hidden">
        </form>
    </body>
</html>
