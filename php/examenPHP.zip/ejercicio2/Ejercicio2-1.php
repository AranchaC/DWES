<html>
<head>
<title>Ejercicio 2.1</title>
</head>
<body>
<h1>Ejercicio 2 Etapa 1</h1>
<form action="Ejercicio2-2.php">
<p>
<label for="nombre">Nombre:</label>
<input type="text" name="nombre" />
</p>
<p><input type="submit" name="siguiente" value="Siguiente" /></p>
</form>
</body>
</html>
