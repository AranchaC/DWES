package com.example.demo;

public record Saludo(long id, String content) {

}
